/*
 * keypad.h
 *
 * Created: 4/10/2023 3:18:14 PM
 *  Author: hanee
 */ 


#ifndef KEYPAD_H_
#define KEYPAD_H_

#include "ATmega32_Rrgiosters.h"
#include "BIT_MATH.h"
#define F_CPU (16000000UL)


#include <util/delay.h>

#define INVALID_KEYPAD_PRESS (0XFF)

void keypad_init();
unsigned char key_get_value();


#endif /* KEYPAD_H_ */