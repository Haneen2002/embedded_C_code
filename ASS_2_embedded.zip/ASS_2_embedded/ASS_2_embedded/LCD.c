#include "LCD.h"
#define F_CPU (16000000UL)
#include<util/delay.h>
#include <stdio.h>

void LCD_Init(void)
{
	LCD_Data_Direction |= 0b00010111;
	
	SET_BIT(LCD_Command_Dirction,RS);
	SET_BIT(LCD_Command_Dirction,EN);

	_delay_ms(20);

	LCD_Command(0x02);
	LCD_Command(0x28);
	LCD_Command(0x0E);
	LCD_Command(0x14);
	LCD_Command(0x01);
	LCD_Command(0xC0);

}

void LCD_Command(unsigned char command)
{
	LCD_Data_Port &=0b11101000;
	LCD_Data_Port |=(((((command & 0xF0) >> 4 ) & 0b00001000) << 1) | (((command & 0xF0)>>4) & 0b00000111));

	CLR_BIT(LCD_Command_Port,RS);
	SET_BIT(LCD_Command_Port,EN);
	_delay_us(1);
	CLR_BIT(LCD_Command_Port,EN);

	_delay_ms(2);
	
	LCD_Data_Port &=0b11101000;
	LCD_Data_Port |=((((command & 0x0F) & 0b00001000) << 1) | ((command & 0x0F) & 0b00000111));

	SET_BIT(LCD_Command_Port,EN);
	_delay_us(1);
	CLR_BIT(LCD_Command_Port,EN);

	_delay_ms(2);
}

void LCD_Char(unsigned char char_data)
{
	LCD_Data_Port &=0b11101000;
	LCD_Data_Port |=(((((char_data & 0xF0) >> 4 ) & 0b00001000) << 1) | (((char_data & 0xF0)>>4) & 0b00000111));

	SET_BIT(LCD_Command_Port,RS);
	SET_BIT(LCD_Command_Port,EN);
	_delay_us(1);
	CLR_BIT(LCD_Command_Port,EN);
	
	
	LCD_Data_Port &=0b11101000;
	_delay_us(100);
	LCD_Data_Port |= ((((char_data & 0x0F) & 0b00001000) << 1) | ((char_data & 0x0F) & 0b00000111));

	SET_BIT(LCD_Command_Port,EN);
	_delay_us(1);
	CLR_BIT(LCD_Command_Port,EN);

	_delay_us(100);
}

void LCD_String(char *str)
{
	int i;
	for(i = 0; str[i] != 0; i++)
	{
		LCD_Char(str[i]);
	}
}


void LCD_print(int val) {
	
	char buffer[3];
	sprintf(buffer, "%d", val);
	LCD_String(buffer);
	
}



