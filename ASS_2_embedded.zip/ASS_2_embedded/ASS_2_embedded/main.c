/*
 * ASS_2_embedded.c
 *
 * Created: 4/10/2023 8:00:51 AM
 * Author : hanee
 */ 

#include "BIT_MATH.h"
#include "ATmega32_Rrgiosters.h"
#include "LCD.h"
#include "keypad.h"
#define F_CPU (16000000UL)
#include<util/delay.h>

int main(void)
{
	unsigned char key;
	unsigned char temp[2];
	int i=0;
	int result=0;
	LCD_Init();
    keypad_init();
	

	while (1)
	{
	  
	    key =key_get_value();
		if(key != INVALID_KEYPAD_PRESS)
		{
			
			if(key == 7)
			{
				LCD_Char('7');
				temp[i]=key;
				i++;
			}
			else if(key ==8)
			{
				LCD_Char('8');
				temp[i]=key;
				i++;
			}
			else if(key ==9)
			{
				LCD_Char('9');
				temp[i]=key;
				i++;
			}
			else if(key == '/')
			{
				LCD_Char('/');
				temp[i]=key;
				i++;
			}
			else if(key ==4)
			{
				LCD_Char('4');
				temp[i]=key;
				i++;
			}
			else if(key ==5)
			{
				LCD_Char('5');
				temp[i]=key;
				i++;
			}
			else if(key ==6)
			{
				LCD_Char('6');
				temp[i]=key;
				i++;
			}
			else if(key == '*')
			{
				LCD_Char('*');
				temp[i]=key;
				i++;
			}
			else if(key ==1)
			{
				LCD_Char('1');
				temp[i]=key;
				i++;
			}
			else if(key ==2)
			{
				LCD_Char('2');
				temp[i]=key;
				i++;
			}
			else if(key ==3)
			{
				LCD_Char('3');
				temp[i]=key;
				i++;
			}
			else if(key =='-')
			{
				LCD_Char('-');
				temp[i]=key;
				i++;
			}
			else if(key ==12)
			{
				LCD_Command(0x01); // Clear the LCD display
				i=0;
			}
			else if(key ==0)
			{
				LCD_Char('0');
				temp[i]=key;
				i++;
			}
			else if(key == '=')
			{
				LCD_Char('=');
				if(temp[1]  == '+')
				{
					result=temp[0]+temp[2];
					LCD_print(result);
				}
				else if(temp[1]  == '-')
				{
					result=temp[0]-temp[2];
					LCD_print(result);
				}
				else if(temp[1]  == '/')
				{
					result=temp[0]/temp[2];
					LCD_print(result);
				}
				else if(temp[1]  == '*')
				{
					result=temp[0]*temp[2];
					LCD_print(result);
				}
				
			}
			else if(key == '+')
			{
				LCD_Char('+');
				temp[i]=key;
				i++;
			}
			else
			  break;
	
		
	  }
	}
}
   
   
   
