#ifndef LCD_H_
#define LCD_H_

#include "BIT_MATH.h"
#include "ATmega32_Rrgiosters.h"

#define LCD_Data_Port PORTB
#define LCD_Data_Direction DDRB
#define LCD_Command_Port PORTA
#define LCD_Command_Dirction DDRA

#define RS pin3
#define EN pin2

void LCD_Init(void);
void LCD_Command(unsigned char command);
void LCD_Char(unsigned char char_data);
void LCD_String(char *srt);
void LCD_print(int val);

#endif /* LCD_H_ */
